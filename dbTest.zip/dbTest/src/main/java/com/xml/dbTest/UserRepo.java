package com.xml.dbTest;

import org.springframework.data.jpa.repository.JpaRepository;

interface UserRepo extends JpaRepository<test1,Integer> {
   
}