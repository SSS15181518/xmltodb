package com.xml.dbTest;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.hibernate.annotations.GenericGenerator;

@Entity
public class test1 {
	@Id
//	@GeneratedValue(generator="system-uuid")
	@GenericGenerator(name="system-uuid", strategy = "uuid")
    String x;
    String y;
    test1() {}
    test1(String x, String y)
    {
        this.x = x;
        this.y = y;
    }
}
