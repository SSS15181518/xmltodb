package com.xml.dbTest;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.fasterxml.jackson.dataformat.xml.XmlMapper;

@SpringBootApplication
public class DbTestApplication implements CommandLineRunner{
	@Autowired UserRepo ob;
	public static void main(String[] args) {
		SpringApplication.run(DbTestApplication.class, args);
	}
	public static SimpleBean whenJavaGotFromXmlStr_thenCorrect() throws IOException {
	    XmlMapper xmlMapper = new XmlMapper();
	    SimpleBean value
	      = xmlMapper.readValue("<SimpleBean><x>6</x><y>Subha6</y></SimpleBean>", SimpleBean.class);
	//    assertTrue(value.getX() == 1 && value.getY() == 2);
	    return value;
	}
	@Override
    public void run(String... args) throws Exception
    {
        // Inserting the data in the mysql table.
		SimpleBean value = whenJavaGotFromXmlStr_thenCorrect();
        test1 first = new test1(value.x, value.y);
        // ob.save() method
        ob.save(first);
    }

}
class SimpleBean {
    public String x;
    public String y;
    
    //standard setters and getters
}